Getting Started with the Power BI REST API
=

The Power BI getting started sample shows you how to
- Register a Native Client Application
- Get an Azure Active Directory access token
- Get all datasets
- Create a dataset
- Add rows to a dataset
- How to add Active Directory Authentication Library

See complete [Getting Started with the Power BI REST API](https://msdn.microsoft.com/en-US/library/dn889824.aspx) article on MSDN.
